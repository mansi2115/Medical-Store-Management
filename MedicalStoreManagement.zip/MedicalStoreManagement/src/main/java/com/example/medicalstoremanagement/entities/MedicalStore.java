package com.example.medicalstoremanagement.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "medical_store")
public class MedicalStore {
	
	@Id
	@Column(name= "ID")
	private int id;
	@Column(name= "STORE_NAME")
	private String storeName;
	@Column(name= "USERNAME", unique = true)
	private String username;
	@Column(name= "PASSWORD")
	private String password;
	
	@Column(name= "STORE_EMAIL_ID")
	private String storeEmailId;
	@Column(name="MOBILE_NUMBER")
	private String mobileNumber;
	@Column(name="ADDRESS_1")
	private String address1;
	@Column(name="ADDRESS_2")
	private String address2;
	@Column(name="STORE_LICENCE")
	private String storeLicence;
	@Column(name="STORE_TYPE_ID") 
	private String storeTypeId;
	@Column(name="STORE_REGISTRATION_NO") 
	private String storeRegistrationNo;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getStoreEmailId() {
		return storeEmailId;
	}
	public void setStoreEmailId(String storeEmailId) {
		this.storeEmailId = storeEmailId;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	public String getStoreLicence() {
		return storeLicence;
	}
	public void setStoreLicence(String storeLicence) {
		this.storeLicence = storeLicence;
	}
	public String getStoreTypeId() {
		return storeTypeId;
	}
	public void setStoreTypeId(String storeTypeId) {
		this.storeTypeId = storeTypeId;
	}
	public String getStoreRegistrationNo() {
		return storeRegistrationNo;
	}
	public void setStoreRegistrationNo(String storeRegistrationNo) {
		this.storeRegistrationNo = storeRegistrationNo;
	}
	
	
	
	
	
	
	 
	   
	   
	   
	   
	   
	   

}
