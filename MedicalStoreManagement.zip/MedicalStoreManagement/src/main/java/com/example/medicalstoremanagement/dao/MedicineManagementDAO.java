package com.example.medicalstoremanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.medicalstoremanagement.entities.MedicineDetails;
import com.example.medicalstoremanagement.entities.MedicineType;

@Repository
public interface MedicineManagementDAO extends JpaRepository<MedicineDetails, Integer>{
	
	@Query("select m from MedicineType m")
	List<MedicineType> getMedicineType();

}
