package com.example.medicalstoremanagement.service;

import java.util.List;

import com.example.medicalstoremanagement.entities.MedicalStore;
import com.example.medicalstoremanagement.entities.MedicineDetails;
import com.example.medicalstoremanagement.entities.MedicineType;
import com.example.medicalstoremanagement.entities.StoreType;

public interface MedicalStoreManagementService {

	//login user
	boolean authenticateUser(String username, String passowrd);
	
	// manage store
	int addStore(MedicalStore medicalStore);
	int editStore(MedicalStore medicalStore);
	void deleteStore(int storeId);
	List<MedicalStore> getStores();
	
	// get medicine type and store type
	List<StoreType> getAllStoreTypes();
	List<MedicineType> getAllMedicineTypes();
	
	// manage medicines
	int addMedicine(MedicineDetails medicineDetails);
	int editMedicine(MedicineDetails medicineDetails);
	void deleteMedicine(int medicineId);
	List<MedicineDetails> getMedicineDetails();

}
