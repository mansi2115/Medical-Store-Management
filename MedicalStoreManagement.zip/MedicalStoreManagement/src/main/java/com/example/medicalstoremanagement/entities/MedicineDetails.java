package com.example.medicalstoremanagement.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "medicine_details")
public class MedicineDetails {
	
	@Id
	@Column(name= "ID") 
	private int id;
	@Column(name= "MEDICINE_NAME")
	private int medicineName;
	@Column(name= "MEDICINE_DETAILS") 
	private int medicineDetails;
	@Column(name= "MEDICINE_PRICE")
	private int medicinePrice;
	@Column(name= "MEDICINE_QUANTITY")
	private int medicineQuantity;
	@Column(name= "MEDICINE_EXPIRY_DATE")
	private int medicineExpiryDate;
	@Column(name= "STORE_ID") 
	private int storeId	;
	@Column(name= "MEDICINE_TYPE_ID")
	private int medicineTypeId;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(int medicineName) {
		this.medicineName = medicineName;
	}
	public int getMedicineDetails() {
		return medicineDetails;
	}
	public void setMedicineDetails(int medicineDetails) {
		this.medicineDetails = medicineDetails;
	}
	public int getMedicinePrice() {
		return medicinePrice;
	}
	public void setMedicinePrice(int medicinePrice) {
		this.medicinePrice = medicinePrice;
	}
	public int getMedicineQuantity() {
		return medicineQuantity;
	}
	public void setMedicineQuantity(int medicineQuantity) {
		this.medicineQuantity = medicineQuantity;
	}
	public int getMedicineExpiryDate() {
		return medicineExpiryDate;
	}
	public void setMedicineExpiryDate(int medicineExpiryDate) {
		this.medicineExpiryDate = medicineExpiryDate;
	}
	public int getStoreId() {
		return storeId;
	}
	public void setStoreId(int storeId) {
		this.storeId = storeId;
	}
	public int getMedicineTypeId() {
		return medicineTypeId;
	}
	public void setMedicineTypeId(int medicineTypeId) {
		this.medicineTypeId = medicineTypeId;
	}
	
	   
	

}
