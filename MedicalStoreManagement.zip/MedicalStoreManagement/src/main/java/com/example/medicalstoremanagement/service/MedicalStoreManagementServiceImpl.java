package com.example.medicalstoremanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.medicalstoremanagement.dao.MedicalStoreManagementDAO;
import com.example.medicalstoremanagement.dao.MedicineManagementDAO;
import com.example.medicalstoremanagement.entities.MedicalStore;
import com.example.medicalstoremanagement.entities.MedicineDetails;
import com.example.medicalstoremanagement.entities.MedicineType;
import com.example.medicalstoremanagement.entities.StoreType;

@Service
@Transactional
public class MedicalStoreManagementServiceImpl implements MedicalStoreManagementService{
	
	@Autowired
	MedicalStoreManagementDAO medicalStoreManagementDAO;
	
	@Autowired
	MedicineManagementDAO medicineManagementDAO;
	
	//authenticate user
	@Override
	public boolean authenticateUser(String username, String passowrd) {
		
		MedicalStore medicalStore = medicalStoreManagementDAO.findByUsername(username);
//		System.out.println(" Service authenticate "+medicalStore);
		
		if(medicalStore != null ) {
			if(medicalStore.getPassword().equals(passowrd)){
				return true;
			}
		}
		return false;
	}

	@Override
	public int addStore(MedicalStore medicalStore) {
		
			MedicalStore medicalStore1= medicalStoreManagementDAO.save(medicalStore);
			return medicalStore1.getId();
		
	}

	@Override
	public int editStore(MedicalStore medicalStore) {
		MedicalStore medicalStore1= medicalStoreManagementDAO.save(medicalStore);
		return medicalStore1.getId();		
	}

	@Override
	public void deleteStore(int storeId) {
		if(medicalStoreManagementDAO.existsById(storeId)) {
			
			medicalStoreManagementDAO.deleteById(storeId);
		}
	}

	@Override
	public List<MedicalStore> getStores() {
		List<MedicalStore> medicalStores = medicalStoreManagementDAO.findAll();
		return medicalStores;
	}

	@Override
	public List<StoreType> getAllStoreTypes() {
		return medicalStoreManagementDAO.getStoreType();
	}

	@Override
	public List<MedicineType> getAllMedicineTypes() {
		return medicineManagementDAO.getMedicineType();
		 
	}

	@Override
	public int addMedicine(MedicineDetails medicineDetails) {
		MedicineDetails mediDetails = medicineManagementDAO.save(medicineDetails);
		return mediDetails.getId();
	}

	@Override
	public int editMedicine(MedicineDetails medicineDetails) {
		MedicineDetails mediDetails = medicineManagementDAO.save(medicineDetails);
		return mediDetails.getId();
	}

	@Override
	public void deleteMedicine(int medicineId) {
		if(medicineManagementDAO.existsById(medicineId)) {
			
			medicineManagementDAO.deleteById(medicineId);
		}		
	}

	@Override
	public List<MedicineDetails> getMedicineDetails() {
		return medicineManagementDAO.findAll();
	}
}
