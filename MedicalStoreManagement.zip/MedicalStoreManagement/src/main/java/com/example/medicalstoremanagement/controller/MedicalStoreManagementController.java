package com.example.medicalstoremanagement.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.medicalstoremanagement.entities.MedicineType;
import com.example.medicalstoremanagement.entities.RequestResponse;
import com.example.medicalstoremanagement.entities.StoreType;
import com.example.medicalstoremanagement.service.MedicalStoreManagementService;


//controller class
@RestController
@RequestMapping("/store")
@CrossOrigin("http://localhost:4200")
public class MedicalStoreManagementController {

	@Autowired
	MedicalStoreManagementService medicalStoreManagementService;
	
	@PostMapping(value= "/authenticate")
	public  ResponseEntity<RequestResponse> authenticate(@RequestBody Map<String, String> userDetails) {
		RequestResponse result ;
		boolean success=medicalStoreManagementService.authenticateUser(userDetails.get("username"), userDetails.get("password"));
		System.out.println("authenticate "+success);
		 result  = new RequestResponse(true,success);
		 return new  ResponseEntity<RequestResponse>(result, HttpStatus.OK);
	}
	
	@GetMapping(value = "/getMedicineTypes")
	public  ResponseEntity<RequestResponse> getMedicineTypes() {
		RequestResponse result ;
		List<MedicineType> medicineType =medicalStoreManagementService.getAllMedicineTypes();
		System.out.println("medicine types "+medicineType);
		 result  = new RequestResponse(true,medicineType);
		 return new  ResponseEntity<RequestResponse>(result, HttpStatus.OK);
	}
	@GetMapping(value = "/getStoreTypes")
	public  ResponseEntity<RequestResponse> getStoreTypes() {
		RequestResponse result ;
		List<StoreType> storeType =medicalStoreManagementService.getAllStoreTypes();
		System.out.println("store types "+storeType);
		 result  = new RequestResponse(true,storeType);
		 return new  ResponseEntity<RequestResponse>(result, HttpStatus.OK);
	}
	
	
}
