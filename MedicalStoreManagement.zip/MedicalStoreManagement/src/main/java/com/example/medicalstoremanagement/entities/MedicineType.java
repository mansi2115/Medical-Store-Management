package com.example.medicalstoremanagement.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name= "medicine_type")
public class MedicineType {

	@Id
	@Column(name= "ID") 
	private int id ;
	@Column(name= "medicine_type_name")
	private String medicineTypeName ;
	@Column(name= "description")
	private String description ;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMedicineTypeName() {
		return medicineTypeName;
	}
	public void setMedicineTypeName(String medicineTypeName) {
		this.medicineTypeName = medicineTypeName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
