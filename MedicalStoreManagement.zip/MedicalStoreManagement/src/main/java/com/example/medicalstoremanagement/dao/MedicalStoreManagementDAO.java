package com.example.medicalstoremanagement.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.medicalstoremanagement.entities.MedicalStore;
import com.example.medicalstoremanagement.entities.StoreType;

@Repository
public interface MedicalStoreManagementDAO extends JpaRepository<MedicalStore, Integer>{
	
	
	MedicalStore findByUsername(String username);
	
	@Query("select m from StoreType m")
	List<StoreType> getStoreType();
}
