package com.example.medicalstoremanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalStoreManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
